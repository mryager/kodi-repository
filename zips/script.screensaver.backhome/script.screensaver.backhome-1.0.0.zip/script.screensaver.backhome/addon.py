import xbmc

if not xbmc.Player().isPlaying():
    xbmc.executebuiltin("ActivateWindow(Home)")